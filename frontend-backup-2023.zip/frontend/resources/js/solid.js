function openNav() {
    document.getElementById("mySidenav").style.display = "block";
  }
  
  function closeNav() {
    document.getElementById("mySidenav").style.display = "none";
  }

//   // Add an event listener to the body element
// document.body.addEventListener('click', function() {
//   // Check if the sidenav is open
//   if (document.getElementById('mySidenav').style.display !== 'none') {
//     // Close the sidenav by setting its display property to 'none'
//     document.getElementById('mySidenav').style.display = 'none';
//   }
// });


